# Binary Provenance

These binaries were copied from the authoritative `milo-brain` Stage 7 final output immediately before this GitHub package was assembled.

## BIT

`milo-altair8800-stage7-final.bit`

- Embedded design name: `altair_nexys_top_stage7`
- Vivado version: 2026.1
- Embedded build date: 2026/09/13
- Embedded build time: 17:40:10
- SHA256: `462630e9423033e7e974aeb0d104c47d2ec0f5ced114a751d78065516ba1a7ea`

## MCS

`milo-altair8800-stage7-final-qspi-x4.mcs`

- QSPI interface: SPI x4
- Configuration memory size: 16 MB
- SHA256: `9952a07c9e7a010fa9c83058438dab1f45b5e69b1b260f48afce7d937661d503`

## Timing

The packaged timing report shows zero failing setup endpoints and positive setup slack. The worst setup slack printed by that report is 0.299 ns.
