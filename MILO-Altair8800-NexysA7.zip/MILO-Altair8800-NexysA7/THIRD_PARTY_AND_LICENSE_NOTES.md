# Third-party and licensing notes

This project integrates or interoperates with historical Altair/CP/M software and a third-party-compatible 8080 core.

No new license is asserted here over third-party material. Preserve original copyright and license notices in any source files. Before publishing historical software images, CP/M binaries, ROMs, or complete recovery-media images publicly, verify redistribution rights.

For a public GitHub repository, it may be preferable to keep `recovery/current-card-first80MiB.img` private and publish only the HDL/build/release files for which redistribution is permitted.
