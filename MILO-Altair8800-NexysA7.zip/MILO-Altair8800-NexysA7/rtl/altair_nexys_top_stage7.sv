`timescale 1ns/1ps

module altair_nexys_top_stage7 (
    input  wire        CLK100MHZ,
    input  wire        CPU_RESETN,

    input  wire        UART_RXD_OUT,
    output wire        UART_TXD_IN,

    output wire [15:0] LED,

    output wire        LED16_R,
    output wire        LED16_G,
    output wire        LED16_B,

    output wire [7:0]  SEG,
    output wire [7:0]  AN,

    output wire        SD_RESET,
    input  wire        SD_CD,
    output wire        SD_SCK,
    output wire        SD_CMD,
    inout  wire [3:0]  SD_DAT
);
    // ========================================================
    // POWER-ON / MANUAL RESET
    // ========================================================
    reg [19:0] por_counter = 0;

    always @(posedge CLK100MHZ) begin
        if (!CPU_RESETN)
            por_counter <= 0;
        else if (!(&por_counter))
            por_counter <= por_counter + 1'b1;
    end

    wire por_reset = !(&por_counter);

    // ========================================================
    // MICROSD BLOCK ENGINE
    // ========================================================
    wire        sd_ready;
    wire        sd_busy;
    wire        sd_done;
    wire        sd_error;
    wire        sd_activity;
    wire        sd_high_capacity;

    wire        sd_req_read;
    wire        sd_req_write;
    wire [31:0] sd_lba;
    wire [8:0]  sd_buf_addr;
    wire [7:0]  sd_buf_dout;
    wire        sd_buf_we;
    wire [7:0]  sd_buf_din;

    sd_spi_block sd0 (
        .clk          (CLK100MHZ),
        .reset        (por_reset),
        .req_read     (sd_req_read),
        .req_write    (sd_req_write),
        .req_lba      (sd_lba),
        .ready        (sd_ready),
        .busy         (sd_busy),
        .done         (sd_done),
        .error        (sd_error),
        .activity     (sd_activity),
        .high_capacity(sd_high_capacity),
        .buf_addr     (sd_buf_addr),
        .buf_dout     (sd_buf_dout),
        .buf_we       (sd_buf_we),
        .buf_din      (sd_buf_din),
        .SD_RESET     (SD_RESET),
        .SD_CD        (SD_CD),
        .SD_SCK       (SD_SCK),
        .SD_CMD       (SD_CMD),
        .SD_DAT       (SD_DAT)
    );

    // ========================================================
    // STAGE 7.2 PERSISTENT SETUP / BOOT PREFLIGHT
    // ========================================================
    wire       setup_tx;
    wire       boot_go;
    wire [2:0] speed_sel;
    wire       write_protect;

    wire        cfg_sd_req_read;
    wire        cfg_sd_req_write;
    wire [31:0] cfg_sd_lba;
    wire [8:0]  cfg_buf_addr;
    wire        cfg_buf_we;
    wire [7:0]  cfg_buf_din;

    altair_boot_setup setup0 (
        .clk              (CLK100MHZ),
        .reset            (por_reset),
        .uart_rx          (UART_RXD_OUT),
        .uart_tx          (setup_tx),
        .sd_ready         (sd_ready),
        .sd_busy          (sd_busy),
        .sd_done          (sd_done),
        .sd_error         (sd_error),
        .sd_high_capacity (sd_high_capacity),
        .cfg_sd_req_read  (cfg_sd_req_read),
        .cfg_sd_req_write (cfg_sd_req_write),
        .cfg_sd_lba       (cfg_sd_lba),
        .cfg_buf_addr     (cfg_buf_addr),
        .cfg_buf_dout     (sd_buf_dout),
        .cfg_buf_we       (cfg_buf_we),
        .cfg_buf_din      (cfg_buf_din),
        .boot_go          (boot_go),
        .speed_sel        (speed_sel),
        .write_protect    (write_protect)
    );

    // The CPU stays stopped until both the setup window is finished and
    // the SD card has initialized successfully.
    wire cpu_reset = por_reset || !boot_go || !sd_ready;

    // ========================================================
    // SELECTABLE AUTHENTIC/TURBO 8080 TWO-PHASE CLOCK
    //
    // DDS square-wave generation keeps exact average frequency even when
    // the requested divisor is fractional against 100 MHz.
    // ========================================================
    reg [31:0] phase_accum = 0;
    reg [31:0] phase_step;

    // DBL always starts at authentic 2 MHz.  Runtime speed is applied
    // only after loaded CP/M begins transmitting on the real 88-2SIO.
    reg bootstrap_complete = 1'b0;
    wire [2:0] effective_speed_sel =
        bootstrap_complete ? speed_sel : 3'd0;

    always @(*) begin
        case (effective_speed_sel)
            3'd0: phase_step = 32'h051EB852; //  2 MHz
            3'd1: phase_step = 32'h0A3D70A4; //  4 MHz
            3'd2: phase_step = 32'h147AE148; //  8 MHz
            3'd3: phase_step = 32'h28F5C28F; // 16 MHz
            default: phase_step = 32'h40000000; // 25 MHz turbo
        endcase
    end

    always @(posedge CLK100MHZ) begin
        if (cpu_reset)
            phase_accum <= 0;
        else
            phase_accum <= phase_accum + phase_step;
    end

    wire f1 = phase_accum[31];
    wire f2 = ~phase_accum[31];

    // ========================================================
    // PRECISE 8080 CORE — EXACT PROVEN STAGE-6 CORE
    // ========================================================
    wire [15:0] addr;
    wire [7:0]  cpu_dout;
    reg  [7:0]  cpu_din;

    wire wr_n;
    wire dbin;
    wire sync;
    wire inte;
    wire hlda;
    wire wait_o;
    wire aena;
    wire dena;

    vm80a_core cpu (
        .pin_clk   (CLK100MHZ),
        .pin_f1    (f1),
        .pin_f2    (f2),
        .pin_reset (cpu_reset),
        .pin_a     (addr),
        .pin_dout  (cpu_dout),
        .pin_din   (cpu_din),
        .pin_aena  (aena),
        .pin_dena  (dena),
        .pin_hold  (1'b0),
        .pin_hlda  (hlda),
        .pin_ready (1'b1),
        .pin_wait  (wait_o),
        .pin_int   (1'b0),
        .pin_inte  (inte),
        .pin_sync  (sync),
        .pin_dbin  (dbin),
        .pin_wr_n  (wr_n)
    );

    // ========================================================
    // 8080 STATUS WORD
    // ========================================================
    reg [7:0] status   = 0;
    reg       old_sync = 0;

    always @(posedge CLK100MHZ) begin
        if (cpu_reset) begin
            status   <= 0;
            old_sync <= 0;
        end
        else begin
            old_sync <= sync;
            if (!old_sync && sync)
                status <= cpu_dout;
        end
    end

    wire mem_read = status[7];
    wire io_read  = status[6];
    wire io_write = status[4];

    // ========================================================
    // I/O BUS EVENT PULSES
    // ========================================================
    wire io_rd_level = dbin && io_read;
    wire io_wr_level = (!wr_n) && io_write;

    reg old_io_rd = 0;
    reg old_io_wr = 0;

    always @(posedge CLK100MHZ) begin
        if (cpu_reset) begin
            old_io_rd <= 0;
            old_io_wr <= 0;
        end
        else begin
            old_io_rd <= io_rd_level;
            old_io_wr <= io_wr_level;
        end
    end

    wire io_rd_start = io_rd_level && !old_io_rd;
    wire io_wr_start = io_wr_level && !old_io_wr;

    // ========================================================
    // 64K MEMORY + AUTHENTIC DBL PROM AT FF00
    // ========================================================
    wire [7:0] ram_dout;
    wire ram_we = (!wr_n) && (!io_write);

    altair_ram64k ram (
        .clk  (CLK100MHZ),
        .addr (addr),
        .din  (cpu_dout),
        .we   (ram_we),
        .dout (ram_dout)
    );

    // ========================================================
    // MITS 88-DCDD -> MICROSD
    // ========================================================
    wire [7:0] dcdd_din;
    wire       dcdd_selected;
    wire [1:0] dcdd_drive;
    wire       dcdd_head_loaded;
    wire [6:0] dcdd_track;
    wire [7:0] dcdd_sector;
    wire [31:0] dcdd_reads;
    wire [31:0] dcdd_writes;
    wire dcdd_disable_after_reads;

    // Setup owns the SD block engine before boot; DCDD owns it after.
    wire        dcdd_sd_req_read;
    wire        dcdd_sd_req_write;
    wire [31:0] dcdd_sd_lba;
    wire [8:0]  dcdd_sd_buf_addr;
    wire        dcdd_sd_buf_we;
    wire [7:0]  dcdd_sd_buf_din;

    altair_dcdd_sd dcdd (
        .clk                 (CLK100MHZ),
        .reset               (cpu_reset),
        .io_rd_start         (io_rd_start),
        .io_wr_start         (io_wr_start),
        .port                (addr[7:0]),
        .cpu_dout            (cpu_dout),
        .cpu_din             (dcdd_din),
        .write_protect       (write_protect),
        .sd_ready            (sd_ready),
        .sd_busy             (sd_busy),
        .sd_done             (sd_done),
        .sd_error            (sd_error),
        .sd_req_read         (dcdd_sd_req_read),
        .sd_req_write        (dcdd_sd_req_write),
        .sd_lba              (dcdd_sd_lba),
        .sd_buf_addr         (dcdd_sd_buf_addr),
        .sd_buf_dout         (sd_buf_dout),
        .sd_buf_we           (dcdd_sd_buf_we),
        .sd_buf_din          (dcdd_sd_buf_din),
        .drive_selected      (dcdd_selected),
        .selected_drive      (dcdd_drive),
        .head_loaded         (dcdd_head_loaded),
        .track               (dcdd_track),
        .sector              (dcdd_sector),
        .data_reads          (dcdd_reads),
        .data_writes         (dcdd_writes),
        .disable_after_reads (dcdd_disable_after_reads)
    );

    // ========================================================
    // SD BLOCK-ENGINE OWNER MUX
    // ========================================================
    assign sd_req_read  = boot_go ? dcdd_sd_req_read  : cfg_sd_req_read;
    assign sd_req_write = boot_go ? dcdd_sd_req_write : cfg_sd_req_write;
    assign sd_lba       = boot_go ? dcdd_sd_lba       : cfg_sd_lba;
    assign sd_buf_addr  = boot_go ? dcdd_sd_buf_addr  : cfg_buf_addr;
    assign sd_buf_we    = boot_go ? dcdd_sd_buf_we    : cfg_buf_we;
    assign sd_buf_din   = boot_go ? dcdd_sd_buf_din   : cfg_buf_din;

    // ========================================================
    // REAL MITS 88-2SIO -> NEXYS USB-UART
    // ========================================================
    wire [7:0] sio_din;
    wire [7:0] sio_control;
    wire sio_tx_activity;
    wire sio_rx_activity;
    wire sio_tx;

    always @(posedge CLK100MHZ) begin
        if (cpu_reset)
            bootstrap_complete <= 1'b0;
        else if (sio_tx_activity)
            bootstrap_complete <= 1'b1;
    end

    altair_2sio_uart #(
        .CLOCK_HZ (100000000),
        .BAUD     (115200)
    ) sio (
        .clk          (CLK100MHZ),
        .reset        (cpu_reset),
        .io_rd_start  (io_rd_start),
        .io_wr_start  (io_wr_start),
        .port         (addr[7:0]),
        .cpu_dout     (cpu_dout),
        .cpu_din      (sio_din),
        .uart_rx      (UART_RXD_OUT),
        .uart_tx      (sio_tx),
        .control_reg  (sio_control),
        .tx_activity  (sio_tx_activity),
        .rx_activity  (sio_rx_activity)
    );

    // Setup owns TX until boot is released; then the real 88-2SIO owns it.
    assign UART_TXD_IN = boot_go ? sio_tx : setup_tx;

    // ========================================================
    // CPU INPUT BUS
    // ========================================================
    always @(*) begin
        cpu_din = 8'hFF;

        if (io_read) begin
            case (addr[7:0])
                8'h08, 8'h09, 8'h0A: cpu_din = dcdd_din;
                8'h10, 8'h11:       cpu_din = sio_din;

                // Proven Stage-6 sense-switch value used by Burcon CP/M.
                8'hFF:              cpu_din = 8'h10;
                default:            cpu_din = 8'hFF;
            endcase
        end
        else if (mem_read) begin
            cpu_din = ram_dout;
        end
    end

    // ========================================================
    // FRONT PANEL PRESENTATION
    // ========================================================
    assign LED = ~addr;

    // Seven-segment display is intentionally completely dark.
    // Nexys A7 anodes and segments are active-low.
    assign SEG = 8'hFF;
    assign AN  = 8'hFF;

    // Stretch every real SD block operation to a visible 75 ms blue flash.
    reg [22:0] disk_led_hold = 0;
    always @(posedge CLK100MHZ) begin
        if (por_reset)
            disk_led_hold <= 0;
        else if (sd_activity)
            disk_led_hold <= 23'd7_500_000;
        else if (disk_led_hold != 0)
            disk_led_hold <= disk_led_hold - 1'b1;
    end

    assign LED16_R = 1'b0;
    assign LED16_G = 1'b0;
    assign LED16_B = (disk_led_hold != 0);

endmodule
