`timescale 1ns/1ps

// ============================================================
// MITS 88-DCDD compatible front end: hybrid boot A: + expanded SD storage.
//
// Ports remain authentic:
//   08h - drive select / inverted status
//   09h - drive control / rotating sector position
//   0Ah - raw 137-byte sector data in/out
//
// Stage 7.4 MAX STORAGE:
//   A: 8MB virtual MITS disk. Tracks 0..5 are embedded in FPGA BRAM for
//      deterministic boot; tracks 6..2047 are SD-backed and writable.
//   B: 8MB virtual MITS disk, SD-backed and writable.
//   C:/D: legacy 77-track disks, preserved from the existing card.
// One 137-byte Altair physical sector maps to one 512-byte SD block.
// ============================================================

module altair_dcdd_sd (
    input  wire        clk,
    input  wire        reset,

    input  wire        io_rd_start,
    input  wire        io_wr_start,
    input  wire [7:0]  port,
    input  wire [7:0]  cpu_dout,
    output reg  [7:0]  cpu_din,

    input  wire        write_protect,

    // SD block engine
    input  wire        sd_ready,
    input  wire        sd_busy,
    input  wire        sd_done,
    input  wire        sd_error,
    output reg         sd_req_read,
    output reg         sd_req_write,
    output reg  [31:0] sd_lba,
    output wire [8:0]  sd_buf_addr,
    input  wire [7:0]  sd_buf_dout,
    output wire        sd_buf_we,
    output wire [7:0]  sd_buf_din,

    output reg         drive_selected,
    output reg  [1:0]  selected_drive,
    output reg         head_loaded,
    output wire [6:0]  track,
    output reg  [7:0]  sector,
    output reg  [31:0] data_reads,
    output reg  [31:0] data_writes,
    output reg         disable_after_reads
);
    localparam integer SECTOR_SIZE  = 137;
    localparam integer SECTORS      = 32;
    localparam integer SMALL_TRACKS = 77;
    localparam integer LARGE_TRACKS = 2048;
    localparam integer BOOT_TRACKS  = 6;

    // Stage 7.4 SD layout. A/B each reserve 65536 SD blocks
    // (2048 tracks * 32 sectors). C/D retain legacy 77-track slots.
    localparam [31:0] DRIVE_A_BASE = 32'd2048;
    localparam [31:0] DRIVE_B_BASE = 32'd67584;
    localparam [31:0] DRIVE_C_BASE = 32'd133120;
    localparam [31:0] DRIVE_D_BASE = 32'd137216;

    // ---------------------------------------------------------
    // DRIVE A — STAGE 7.4 HYBRID 8MB SYSTEM DISK
    //
    // Only system tracks 0..5 are embedded. This preserves deterministic
    // DBL/CP/M boot while allowing the CP/M filesystem (track 6+) to be
    // writable and vastly larger on microSD.
    // ---------------------------------------------------------
    localparam integer DRIVE_A_ROM_BYTES = BOOT_TRACKS * SECTORS * SECTOR_SIZE;
    (* rom_style = "block" *) reg [7:0] drive_a_rom [0:DRIVE_A_ROM_BYTES-1];
    reg [7:0] drive_a_q;
    reg [8:0] current_byte;

    initial begin
        $readmemh(
            "memory/CPM8_A_BOOT_ROM.mem",
            drive_a_rom
        );
    end

    reg [10:0] tracks [0:3];
    assign track = tracks[selected_drive][6:0];

    wire drive_a_boot_rom_selected =
        drive_selected &&
        (selected_drive == 2'd0) &&
        (tracks[0] < BOOT_TRACKS);

    // Stage 7.4 boot-ROM timing pipeline:
    // Deeply pipeline the embedded A: address path:
    //
    //   track/sector -> linear sector -> *137 sector base
    //                -> + byte offset -> BRAM read
    //
    // The 8080 bootstrap runs at 2 MHz while this pipeline runs at 100 MHz,
    // so the extra internal clocks are harmless but eliminate a long
    // arithmetic-to-BRAM timing path.
    wire [11:0] drive_a_sector_index_calc =
        ({9'd0, tracks[0][2:0]} << 5) + {4'd0, sector};

    reg  [11:0] drive_a_sector_index_reg;
    wire [18:0] drive_a_sector_base_calc =
        drive_a_sector_index_reg * 19'd137;

    reg  [18:0] drive_a_sector_base_reg;
    wire [18:0] drive_a_rom_addr_calc =
        drive_a_sector_base_reg + {10'd0, current_byte};

    reg [18:0] drive_a_rom_addr_reg;

    // Every pipeline register has exactly one procedural driver.
    always @(posedge clk) begin
        if (reset) begin
            drive_a_sector_index_reg <= 12'd0;
            drive_a_sector_base_reg  <= 19'd0;
            drive_a_rom_addr_reg     <= 19'd0;
        end
        else begin
            drive_a_sector_index_reg <= drive_a_sector_index_calc;
            drive_a_sector_base_reg  <= drive_a_sector_base_calc;
            drive_a_rom_addr_reg     <= drive_a_rom_addr_calc;
        end
    end

    // Clean synchronous block-ROM read.
    always @(posedge clk) begin
        if (drive_a_rom_addr_reg < DRIVE_A_ROM_BYTES)
            drive_a_q <= drive_a_rom[drive_a_rom_addr_reg];
        else
            drive_a_q <= 8'h00;
    end

    function automatic [31:0] drive_base;
        input [1:0] drive;
        begin
            case (drive)
                2'd0: drive_base = DRIVE_A_BASE;
                2'd1: drive_base = DRIVE_B_BASE;
                2'd2: drive_base = DRIVE_C_BASE;
                default: drive_base = DRIVE_D_BASE;
            endcase
        end
    endfunction

    function automatic [31:0] make_lba;
        input [1:0] drive;
        input [10:0] trk;
        input [7:0] sec;
        begin
            make_lba = drive_base(drive) + ({21'd0, trk} << 5) + sec;
        end
    endfunction

    function automatic [10:0] max_track_for_drive;
        input [1:0] drive;
        begin
            if (drive < 2)
                max_track_for_drive = LARGE_TRACKS - 1;
            else
                max_track_for_drive = SMALL_TRACKS - 1;
        end
    endfunction

    // Positive internal flags.  Port 08 returns their inverse, matching
    // the real board and SIMH convention.
    // bit 0 W: write circuit ready
    // bit 2 H: head loaded
    // bit 6 Z: track zero
    // bit 7 R: read data ready
    reg [7:0] flags;

    reg       sector_true;
    reg       cache_valid;
    reg       read_pending;
    reg       read_inflight;
    reg       write_pending;
    reg       write_inflight;
    reg       write_mode;

    assign sd_buf_addr = current_byte;
    assign sd_buf_din  = cpu_dout;
    assign sd_buf_we   = io_wr_start &&
                         (port == 8'h0A) &&
                         drive_selected && !drive_a_boot_rom_selected &&
                         head_loaded && write_mode && flags[0] &&
                         (current_byte < SECTOR_SIZE);

    integer k;
    wire [7:0] sector_after = (sector >= 31) ? 8'd0 : (sector + 1'b1);

    always @(posedge clk) begin
        sd_req_read  <= 1'b0;
        sd_req_write <= 1'b0;

        if (reset) begin
            cpu_din             <= 8'hFF;
            drive_selected      <= 1'b0;
            selected_drive      <= 2'd0;
            head_loaded         <= 1'b0;
            sector              <= 8'hFF;
            sector_true         <= 1'b0;
            current_byte        <= 9'h1FF;
            flags               <= 8'h00;
            cache_valid         <= 1'b0;
            read_pending        <= 1'b0;
            read_inflight       <= 1'b0;
            write_pending       <= 1'b0;
            write_inflight      <= 1'b0;
            write_mode          <= 1'b0;
            sd_lba              <= 32'd0;
            data_reads          <= 32'd0;
            data_writes         <= 32'd0;
            disable_after_reads <= 1'b0;

            for (k = 0; k < 4; k = k + 1)
                tracks[k] <= 11'd0;
        end
        else begin
            // ---------------------------------------------------------
            // Launch deferred SD operations only while the block engine
            // is idle.  sd_lba was latched before the pending flag.
            // ---------------------------------------------------------
            if (read_pending && sd_ready && !sd_busy &&
                !read_inflight && !write_inflight) begin
                sd_req_read  <= 1'b1;
                read_pending <= 1'b0;
                read_inflight <= 1'b1;
            end

            if (write_pending && sd_ready && !sd_busy &&
                !read_inflight && !write_inflight) begin
                if (write_protect) begin
                    // Safe mode: consume the write exactly like hardware,
                    // but intentionally do not alter the card.
                    write_pending <= 1'b0;
                    data_writes   <= data_writes + 1'b1;
                end
                else begin
                    sd_req_write   <= 1'b1;
                    write_pending  <= 1'b0;
                    write_inflight <= 1'b1;
                end
            end

            if (sd_done) begin
                if (read_inflight) begin
                    read_inflight <= 1'b0;
                    if (!sd_error) begin
                        cache_valid <= 1'b1;
                        current_byte <= 0;
                        flags[7] <= 1'b1;
                        data_reads <= data_reads + 1'b1;
                    end
                    else begin
                        cache_valid <= 1'b0;
                        flags[7] <= 1'b0;
                    end
                end

                if (write_inflight) begin
                    write_inflight <= 1'b0;
                    flags[0] <= 1'b0;
                    if (!sd_error)
                        data_writes <= data_writes + 1'b1;
                end
            end

            // =========================================================
            // I/O WRITE
            // =========================================================
            if (io_wr_start) begin
                case (port)
                    // -------------------------------------------------
                    // 08h: select/disable drive
                    // -------------------------------------------------
                    8'h08: begin
                        if (cpu_dout[7]) begin
                            drive_selected <= 1'b0;
                            head_loaded    <= 1'b0;
                            flags          <= 8'h00;
                            cache_valid    <= 1'b0;
                            read_pending   <= 1'b0;
                            write_mode     <= 1'b0;

                            if (data_reads != 0)
                                disable_after_reads <= 1'b1;
                        end
                        else if (cpu_dout[3:0] < 4) begin
                            selected_drive <= cpu_dout[1:0];
                            drive_selected <= 1'b1;
                            head_loaded    <= 1'b0;
                            sector         <= 8'hFF;
                            current_byte   <= 9'h1FF;
                            sector_true    <= 1'b0;
                            cache_valid    <= 1'b0;
                            read_pending   <= 1'b0;
                            write_mode     <= 1'b0;

                            // Basic enabled/move-head state plus track-zero.
                            if (tracks[cpu_dout[1:0]] == 0)
                                flags <= 8'h5A;
                            else
                                flags <= 8'h1A;
                        end
                        else begin
                            drive_selected <= 1'b0;
                            flags <= 8'h00;
                        end
                    end

                    // -------------------------------------------------
                    // 09h: drive control
                    // -------------------------------------------------
                    8'h09: begin
                        if (drive_selected &&
                            !read_inflight && !write_inflight &&
                            !read_pending && !write_pending) begin

                            // STEP IN
                            if (cpu_dout[0]) begin
                                if (tracks[selected_drive] <
                                    max_track_for_drive(selected_drive))
                                    tracks[selected_drive] <= tracks[selected_drive] + 1'b1;
                                flags[6] <= 1'b0;
                                sector <= 8'hFF;
                                current_byte <= 9'h1FF;
                                sector_true <= 1'b0;
                                cache_valid <= 1'b0;
                            end

                            // STEP OUT
                            if (cpu_dout[1]) begin
                                if (tracks[selected_drive] > 0)
                                    tracks[selected_drive] <= tracks[selected_drive] - 1'b1;
                                if (tracks[selected_drive] <= 1)
                                    flags[6] <= 1'b1;
                                sector <= 8'hFF;
                                current_byte <= 9'h1FF;
                                sector_true <= 1'b0;
                                cache_valid <= 1'b0;
                            end

                            // HEAD LOAD
                            if (cpu_dout[2]) begin
                                head_loaded <= 1'b1;
                                flags[2] <= 1'b1;
                                // Authentic 88-DCDD behavior: HEAD LOAD
                                // immediately asserts READ READY. Sector True
                                // is independently delayed until the requested
                                // SD block is cached, avoiding the DBL deadlock.
                                flags[7] <= 1'b1;
                            end

                            // HEAD UNLOAD
                            if (cpu_dout[3]) begin
                                head_loaded <= 1'b0;
                                flags[2] <= 1'b0;
                                flags[7] <= 1'b0;
                                sector <= 8'hFF;
                                current_byte <= 9'h1FF;
                                sector_true <= 1'b0;
                                cache_valid <= 1'b0;
                                read_pending <= 1'b0;
                                write_mode <= 1'b0;
                            end

                            // WRITE ENABLE SEQUENCE
                            if (cpu_dout[7] && head_loaded) begin
                                write_mode   <= 1'b1;
                                current_byte <= 0;
                                flags[0]     <= 1'b1;
                                if (drive_a_boot_rom_selected) begin
                                    // Embedded boot tracks are protected; acknowledge
                                    // locally and discard their bytes.
                                    flags[7]    <= 1'b1;
                                    cache_valid <= 1'b1;
                                end
                                else begin
                                    flags[7]    <= 1'b0;
                                    cache_valid <= 1'b0;
                                    sd_lba <= make_lba(
                                        selected_drive,
                                        tracks[selected_drive],
                                        sector
                                    );
                                end
                            end
                        end
                    end

                    // -------------------------------------------------
                    // 0Ah: raw sector data write
                    // -------------------------------------------------
                    8'h0A: begin
                        if (drive_selected && head_loaded && write_mode &&
                            flags[0] && (current_byte < SECTOR_SIZE)) begin

                            if (current_byte == SECTOR_SIZE-1) begin
                                current_byte <= current_byte + 1'b1;
                                flags[0]     <= 1'b0;
                                write_mode   <= 1'b0;
                                if (drive_a_boot_rom_selected) begin
                                    // Embedded A: boot tracks are intentionally immutable.
                                    // Consume writes safely but never alter them.
                                    write_pending <= 1'b0;
                                    data_writes <= data_writes + 1'b1;
                                end
                                else begin
                                    write_pending <= 1'b1;
                                end
                            end
                            else begin
                                current_byte <= current_byte + 1'b1;
                            end
                        end
                    end

                    default: begin end
                endcase
            end

            // =========================================================
            // I/O READ
            // =========================================================
            if (io_rd_start) begin
                case (port)
                    // -------------------------------------------------
                    // 08h: inverted status
                    // -------------------------------------------------
                    8'h08: begin
                        if (drive_selected)
                            cpu_din <= ~flags;
                        else
                            cpu_din <= 8'hFF;
                    end

                    // -------------------------------------------------
                    // 09h: rotating sector position
                    // -------------------------------------------------
                    8'h09: begin
                        if (!drive_selected || !head_loaded) begin
                            cpu_din <= 8'hFF;
                        end
                        else if (drive_a_boot_rom_selected) begin
                            // Embedded A: boot tracks use the exact Stage-6/SIMH timing.
                            // No SD latency is involved while loading CP/M.
                            if (!sector_true) begin
                                sector_true <= 1'b1;
                                cpu_din <= 8'hC1 | ((sector << 1) & 8'h3E);
                            end
                            else begin
                                sector_true  <= 1'b0;
                                sector       <= sector_after;
                                current_byte <= 0;
                                cache_valid  <= 1'b1;
                                flags[7]     <= 1'b1;
                                cpu_din <= 8'hC0 | ((sector_after << 1) & 8'h3E);
                            end
                        end
                        else if (read_pending || read_inflight ||
                                 write_pending || write_inflight || sd_busy) begin
                            // Freeze emulated rotation while SD catches up.
                            // Sector True remains false (bit0=1), so software
                            // cannot enter the data phase until the block is in
                            // FPGA RAM.
                            cpu_din <= 8'hC1 | ((sector << 1) & 8'h3E);
                        end
                        else if (sector_true && cache_valid) begin
                            // The prefetched sector is now physically "under"
                            // the head.  Only now advertise Sector True.
                            sector_true <= 1'b0;
                            cpu_din <= 8'hC0 | ((sector << 1) & 8'h3E);
                        end
                        else begin
                            // Advance to the next physical sector and prefetch
                            // its one-to-one SD block.  This read returns T=1;
                            // the next poll returns T=0 after SD completion.
                            sector       <= sector_after;
                            current_byte <= 0;
                            cache_valid  <= 1'b0;
                            flags[7]     <= 1'b0;
                            sector_true  <= 1'b1;

                            sd_lba <= make_lba(
                                selected_drive,
                                tracks[selected_drive],
                                sector_after
                            );
                            read_pending <= 1'b1;

                            cpu_din <= 8'hC1 | ((sector_after << 1) & 8'h3E);
                        end
                    end

                    // -------------------------------------------------
                    // 0Ah: raw sector data read
                    // -------------------------------------------------
                    8'h0A: begin
                        if (!drive_selected || !head_loaded) begin
                            cpu_din <= 8'h00;
                        end
                        else if (drive_a_boot_rom_selected &&
                                 (current_byte < SECTOR_SIZE)) begin
                            cpu_din <= drive_a_q;
                            current_byte <= current_byte + 1'b1;
                            data_reads <= data_reads + 1'b1;
                        end
                        else if (cache_valid && (current_byte < SECTOR_SIZE)) begin
                            cpu_din <= sd_buf_dout;
                            current_byte <= current_byte + 1'b1;
                        end
                        else begin
                            // Correct software waits for status R before
                            // reading.  Return zero rather than stale data.
                            cpu_din <= 8'h00;
                        end
                    end

                    default: cpu_din <= 8'hFF;
                endcase
            end
        end
    end
endmodule
