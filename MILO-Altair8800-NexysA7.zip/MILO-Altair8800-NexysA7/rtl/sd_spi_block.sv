`timescale 1ns/1ps

// ============================================================
// Nexys A7 microSD SPI block controller
//
// - Powers the Nexys A7 microSD slot by holding SD_RESET low.
// - Initializes SD/SDHC cards in SPI mode.
// - Supports single-block CMD17 reads and CMD24 writes.
// - Owns a 512-byte transfer buffer shared with the 88-DCDD shim.
// - Slow init clock ~250 kHz, run clock ~12.5 MHz.
// ============================================================

module sd_spi_byte_master (
    input  wire       clk,
    input  wire       reset,
    input  wire       start,
    input  wire       fast_mode,
    input  wire [7:0] tx_data,
    output reg  [7:0] rx_data,
    output reg        busy,
    output reg        done,
    output reg        sck,
    output reg        mosi,
    input  wire       miso
);
    localparam integer SLOW_HALF_DIV = 200; // 100 MHz/(2*200)=250 kHz
    localparam integer FAST_HALF_DIV = 4;   // 100 MHz/(2*4)=12.5 MHz

    reg [8:0] div_count;
    reg [2:0] bit_index;
    reg [7:0] tx_latched;
    reg [7:0] rx_shift;

    wire [8:0] half_div = fast_mode ? FAST_HALF_DIV : SLOW_HALF_DIV;

    always @(posedge clk) begin
        done <= 1'b0;

        if (reset) begin
            rx_data    <= 8'hFF;
            busy       <= 1'b0;
            sck        <= 1'b0;
            mosi       <= 1'b1;
            div_count  <= 0;
            bit_index  <= 3'd7;
            tx_latched <= 8'hFF;
            rx_shift   <= 8'hFF;
        end
        else if (!busy) begin
            sck  <= 1'b0;
            mosi <= 1'b1;

            if (start) begin
                busy       <= 1'b1;
                div_count  <= 0;
                bit_index  <= 3'd7;
                tx_latched <= tx_data;
                rx_shift   <= 8'h00;
                mosi       <= tx_data[7];
            end
        end
        else begin
            if (div_count == half_div - 1'b1) begin
                div_count <= 0;

                if (!sck) begin
                    // SPI mode 0: sample on rising edge.
                    sck <= 1'b1;
                    rx_shift[bit_index] <= miso;
                end
                else begin
                    sck <= 1'b0;

                    if (bit_index == 0) begin
                        busy    <= 1'b0;
                        done    <= 1'b1;
                        rx_data <= rx_shift;
                        mosi    <= 1'b1;
                    end
                    else begin
                        bit_index <= bit_index - 1'b1;
                        mosi <= tx_latched[bit_index - 1'b1];
                    end
                end
            end
            else begin
                div_count <= div_count + 1'b1;
            end
        end
    end
endmodule


module sd_spi_block (
    input  wire        clk,
    input  wire        reset,

    input  wire        req_read,
    input  wire        req_write,
    input  wire [31:0] req_lba,

    output reg         ready,
    output reg         busy,
    output reg         done,
    output reg         error,
    output reg         activity,
    output wire        high_capacity,

    input  wire [8:0]  buf_addr,
    output wire [7:0]  buf_dout,
    input  wire        buf_we,
    input  wire [7:0]  buf_din,

    output wire        SD_RESET,
    input  wire        SD_CD,
    output wire        SD_SCK,
    output wire        SD_CMD,
    inout  wire [3:0]  SD_DAT
);
    // Nexys A7: SD_RESET must be actively LOW to power the slot.
    assign SD_RESET = 1'b0;

    // SPI mapping on the native SD pins:
    // CMD=DI/MOSI, DAT0=DO/MISO, DAT3=CS, DAT1/2 unused-high.
    reg sd_cs;
    wire sd_miso = SD_DAT[0];
    assign SD_DAT[0] = 1'bz;
    assign SD_DAT[1] = 1'b1;
    assign SD_DAT[2] = 1'b1;
    assign SD_DAT[3] = sd_cs;

    wire card_present = ~SD_CD;

    reg spi_fast;
    reg spi_start;
    reg [7:0] spi_tx;
    wire [7:0] spi_rx;
    wire spi_busy;
    wire spi_done;
    wire spi_sck;
    wire spi_mosi;

    assign SD_SCK = spi_sck;
    assign SD_CMD = spi_mosi;

    sd_spi_byte_master spi0 (
        .clk       (clk),
        .reset     (reset),
        .start     (spi_start),
        .fast_mode (spi_fast),
        .tx_data   (spi_tx),
        .rx_data   (spi_rx),
        .busy      (spi_busy),
        .done      (spi_done),
        .sck       (spi_sck),
        .mosi      (spi_mosi),
        .miso      (sd_miso)
    );

    // 512-byte transfer buffer.  The 88-DCDD side writes this while the
    // SD engine is idle; CMD17 fills it; CMD24 drains it.
    reg [7:0] block_buf [0:511];
    assign buf_dout = block_buf[buf_addr];

    reg hc;
    assign high_capacity = hc;

    reg [31:0] latched_lba;
    reg [31:0] cmd_arg;
    reg [5:0]  cmd_num;
    reg [7:0]  cmd_crc;
    reg [2:0]  cmd_index;
    reg [7:0]  r1;
    reg [7:0]  cmd_next;
    reg [7:0]  gap_next;
    reg        byte_active;

    reg [8:0]  data_index;
    reg [3:0]  init_dummy_count;
    reg [15:0] init_loop_count;
    reg [23:0] poll_count;
    reg [1:0]  extra_index;
    reg [7:0]  ocr0;
    reg        sd_v2;

    reg [31:0] power_count;

    localparam [7:0]
        ST_POWER             = 8'd0,
        ST_INIT_DUMMY        = 8'd1,
        ST_LAUNCH_CMD0       = 8'd2,
        ST_AFTER_CMD0        = 8'd3,
        ST_LAUNCH_CMD8       = 8'd4,
        ST_AFTER_CMD8        = 8'd5,
        ST_READ_R7           = 8'd6,
        ST_LAUNCH_CMD55      = 8'd7,
        ST_AFTER_CMD55       = 8'd8,
        ST_LAUNCH_ACMD41     = 8'd9,
        ST_AFTER_ACMD41      = 8'd10,
        ST_LAUNCH_CMD58      = 8'd11,
        ST_AFTER_CMD58       = 8'd12,
        ST_READ_OCR          = 8'd13,
        ST_LAUNCH_CMD16      = 8'd14,
        ST_AFTER_CMD16       = 8'd15,
        ST_READY             = 8'd16,

        ST_CMD_SEND          = 8'd20,
        ST_CMD_R1            = 8'd21,
        ST_GAP               = 8'd22,

        ST_AFTER_CMD17       = 8'd30,
        ST_READ_TOKEN        = 8'd31,
        ST_READ_DATA         = 8'd32,
        ST_READ_CRC1         = 8'd33,
        ST_READ_CRC2         = 8'd34,
        ST_FINISH_READ       = 8'd35,

        ST_AFTER_CMD24       = 8'd40,
        ST_WRITE_PRETOKEN    = 8'd41,
        ST_WRITE_TOKEN       = 8'd42,
        ST_WRITE_DATA        = 8'd43,
        ST_WRITE_CRC1        = 8'd44,
        ST_WRITE_CRC2        = 8'd45,
        ST_WRITE_RESPONSE    = 8'd46,
        ST_WRITE_BUSY        = 8'd47,
        ST_FINISH_WRITE      = 8'd48,

        ST_ERROR             = 8'd63;

    reg [7:0] state;

    function automatic [7:0] command_byte;
        input [2:0] idx;
        begin
            case (idx)
                3'd0: command_byte = 8'h40 | {2'b00, cmd_num};
                3'd1: command_byte = cmd_arg[31:24];
                3'd2: command_byte = cmd_arg[23:16];
                3'd3: command_byte = cmd_arg[15:8];
                3'd4: command_byte = cmd_arg[7:0];
                default: command_byte = cmd_crc;
            endcase
        end
    endfunction

    function automatic [31:0] card_address;
        input [31:0] lba;
        begin
            card_address = hc ? lba : (lba << 9);
        end
    endfunction

    integer i;

    always @(posedge clk) begin
        spi_start <= 1'b0;
        done      <= 1'b0;
        activity  <= 1'b0;

        // Host-side buffer writes are only accepted while the SD engine is
        // not carrying out a card transaction.
        if (buf_we && !busy)
            block_buf[buf_addr] <= buf_din;

        if (reset) begin
            ready            <= 1'b0;
            busy             <= 1'b1;
            error            <= 1'b0;
            activity         <= 1'b0;
            spi_fast         <= 1'b0;
            sd_cs            <= 1'b1;
            spi_tx           <= 8'hFF;
            latched_lba      <= 0;
            cmd_arg          <= 0;
            cmd_num          <= 0;
            cmd_crc          <= 8'hFF;
            cmd_index        <= 0;
            r1               <= 8'hFF;
            cmd_next         <= 0;
            gap_next         <= 0;
            byte_active      <= 1'b0;
            data_index       <= 0;
            init_dummy_count <= 0;
            init_loop_count  <= 0;
            poll_count       <= 0;
            extra_index      <= 0;
            ocr0             <= 0;
            sd_v2            <= 1'b0;
            hc               <= 1'b0;
            power_count      <= 0;
            state            <= ST_POWER;

            for (i = 0; i < 512; i = i + 1)
                block_buf[i] <= 8'h00;
        end
        else begin
            case (state)
                // --------------------------------------------------------
                // Power-up / SPI-mode entry
                // --------------------------------------------------------
                ST_POWER: begin
                    sd_cs    <= 1'b1;
                    spi_fast <= 1'b0;
                    busy     <= 1'b1;
                    ready    <= 1'b0;

                    // 20 ms after FPGA configuration gives the board's SD
                    // power switch and card ample time to settle.
                    if (power_count >= 32'd2_000_000) begin
                        power_count      <= 0;
                        init_dummy_count <= 0;
                        byte_active      <= 1'b0;
                        state            <= ST_INIT_DUMMY;
                    end
                    else begin
                        power_count <= power_count + 1'b1;
                    end
                end

                ST_INIT_DUMMY: begin
                    sd_cs <= 1'b1;

                    if (!byte_active) begin
                        spi_tx      <= 8'hFF;
                        spi_start   <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        if (init_dummy_count == 4'd9) begin
                            state <= ST_LAUNCH_CMD0;
                        end
                        else begin
                            init_dummy_count <= init_dummy_count + 1'b1;
                        end
                    end
                end

                ST_LAUNCH_CMD0: begin
                    sd_cs     <= 1'b0;
                    cmd_num   <= 6'd0;
                    cmd_arg   <= 32'h00000000;
                    cmd_crc   <= 8'h95;
                    cmd_index <= 0;
                    cmd_next  <= ST_AFTER_CMD0;
                    poll_count <= 0;
                    byte_active <= 1'b0;
                    state <= ST_CMD_SEND;
                end

                ST_AFTER_CMD0: begin
                    if (r1 != 8'h01) begin
                        state <= ST_ERROR;
                    end
                    else begin
                        gap_next <= ST_LAUNCH_CMD8;
                        byte_active <= 1'b0;
                        state <= ST_GAP;
                    end
                end

                ST_LAUNCH_CMD8: begin
                    sd_cs     <= 1'b0;
                    cmd_num   <= 6'd8;
                    cmd_arg   <= 32'h000001AA;
                    cmd_crc   <= 8'h87;
                    cmd_index <= 0;
                    cmd_next  <= ST_AFTER_CMD8;
                    poll_count <= 0;
                    byte_active <= 1'b0;
                    state <= ST_CMD_SEND;
                end

                ST_AFTER_CMD8: begin
                    if (r1 == 8'h01) begin
                        sd_v2       <= 1'b1;
                        extra_index <= 0;
                        byte_active <= 1'b0;
                        state       <= ST_READ_R7;
                    end
                    else if (r1[2]) begin
                        // Pre-SDHC card: no CMD8 support.
                        sd_v2 <= 1'b0;
                        gap_next <= ST_LAUNCH_CMD55;
                        byte_active <= 1'b0;
                        state <= ST_GAP;
                    end
                    else begin
                        state <= ST_ERROR;
                    end
                end

                ST_READ_R7: begin
                    if (!byte_active) begin
                        spi_tx      <= 8'hFF;
                        spi_start   <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        if (extra_index == 2'd3) begin
                            gap_next <= ST_LAUNCH_CMD55;
                            state <= ST_GAP;
                        end
                        else begin
                            extra_index <= extra_index + 1'b1;
                        end
                    end
                end

                ST_LAUNCH_CMD55: begin
                    sd_cs     <= 1'b0;
                    cmd_num   <= 6'd55;
                    cmd_arg   <= 32'h00000000;
                    cmd_crc   <= 8'hFF;
                    cmd_index <= 0;
                    cmd_next  <= ST_AFTER_CMD55;
                    poll_count <= 0;
                    byte_active <= 1'b0;
                    state <= ST_CMD_SEND;
                end

                ST_AFTER_CMD55: begin
                    if ((r1 == 8'h01) || (r1 == 8'h00)) begin
                        gap_next <= ST_LAUNCH_ACMD41;
                        byte_active <= 1'b0;
                        state <= ST_GAP;
                    end
                    else begin
                        state <= ST_ERROR;
                    end
                end

                ST_LAUNCH_ACMD41: begin
                    sd_cs     <= 1'b0;
                    cmd_num   <= 6'd41;
                    cmd_arg   <= sd_v2 ? 32'h40000000 : 32'h00000000;
                    cmd_crc   <= 8'hFF;
                    cmd_index <= 0;
                    cmd_next  <= ST_AFTER_ACMD41;
                    poll_count <= 0;
                    byte_active <= 1'b0;
                    state <= ST_CMD_SEND;
                end

                ST_AFTER_ACMD41: begin
                    if (r1 == 8'h00) begin
                        gap_next <= ST_LAUNCH_CMD58;
                        byte_active <= 1'b0;
                        state <= ST_GAP;
                    end
                    else if ((r1 == 8'h01) && (init_loop_count < 16'd2000)) begin
                        init_loop_count <= init_loop_count + 1'b1;
                        gap_next <= ST_LAUNCH_CMD55;
                        byte_active <= 1'b0;
                        state <= ST_GAP;
                    end
                    else begin
                        state <= ST_ERROR;
                    end
                end

                ST_LAUNCH_CMD58: begin
                    sd_cs     <= 1'b0;
                    cmd_num   <= 6'd58;
                    cmd_arg   <= 32'h00000000;
                    cmd_crc   <= 8'hFF;
                    cmd_index <= 0;
                    cmd_next  <= ST_AFTER_CMD58;
                    poll_count <= 0;
                    byte_active <= 1'b0;
                    state <= ST_CMD_SEND;
                end

                ST_AFTER_CMD58: begin
                    if (r1 != 8'h00) begin
                        state <= ST_ERROR;
                    end
                    else begin
                        extra_index <= 0;
                        ocr0 <= 0;
                        byte_active <= 1'b0;
                        state <= ST_READ_OCR;
                    end
                end

                ST_READ_OCR: begin
                    if (!byte_active) begin
                        spi_tx      <= 8'hFF;
                        spi_start   <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        if (extra_index == 0)
                            ocr0 <= spi_rx;

                        if (extra_index == 2'd3) begin
                            hc <= ocr0[6];
                            if (ocr0[6]) begin
                                gap_next <= ST_READY;
                            end
                            else begin
                                gap_next <= ST_LAUNCH_CMD16;
                            end
                            state <= ST_GAP;
                        end
                        else begin
                            extra_index <= extra_index + 1'b1;
                        end
                    end
                end

                ST_LAUNCH_CMD16: begin
                    sd_cs     <= 1'b0;
                    cmd_num   <= 6'd16;
                    cmd_arg   <= 32'd512;
                    cmd_crc   <= 8'hFF;
                    cmd_index <= 0;
                    cmd_next  <= ST_AFTER_CMD16;
                    poll_count <= 0;
                    byte_active <= 1'b0;
                    state <= ST_CMD_SEND;
                end

                ST_AFTER_CMD16: begin
                    if (r1 != 8'h00)
                        state <= ST_ERROR;
                    else begin
                        gap_next <= ST_READY;
                        byte_active <= 1'b0;
                        state <= ST_GAP;
                    end
                end

                // --------------------------------------------------------
                // Shared command sender / R1 response receiver
                // --------------------------------------------------------
                ST_CMD_SEND: begin
                    if (!byte_active) begin
                        spi_tx      <= command_byte(cmd_index);
                        spi_start   <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        if (cmd_index == 3'd5) begin
                            poll_count <= 0;
                            state <= ST_CMD_R1;
                        end
                        else begin
                            cmd_index <= cmd_index + 1'b1;
                        end
                    end
                end

                ST_CMD_R1: begin
                    if (!byte_active) begin
                        spi_tx      <= 8'hFF;
                        spi_start   <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        if (!spi_rx[7]) begin
                            r1 <= spi_rx;
                            state <= cmd_next;
                        end
                        else if (poll_count >= 24'd1_000_000) begin
                            state <= ST_ERROR;
                        end
                        else begin
                            poll_count <= poll_count + 1'b1;
                        end
                    end
                end

                ST_GAP: begin
                    sd_cs <= 1'b1;
                    if (!byte_active) begin
                        spi_tx      <= 8'hFF;
                        spi_start   <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        state <= gap_next;
                    end
                end

                // --------------------------------------------------------
                // Ready / transaction launch
                // --------------------------------------------------------
                ST_READY: begin
                    sd_cs    <= 1'b1;
                    spi_fast <= 1'b1;
                    ready    <= 1'b1;
                    busy     <= 1'b0;

                    if (req_read) begin
                        latched_lba <= req_lba;
                        busy        <= 1'b1;
                        activity    <= 1'b1;
                        sd_cs       <= 1'b0;
                        cmd_num     <= 6'd17;
                        cmd_arg     <= card_address(req_lba);
                        cmd_crc     <= 8'hFF;
                        cmd_index   <= 0;
                        cmd_next    <= ST_AFTER_CMD17;
                        poll_count  <= 0;
                        byte_active <= 1'b0;
                        state       <= ST_CMD_SEND;
                    end
                    else if (req_write) begin
                        latched_lba <= req_lba;
                        busy        <= 1'b1;
                        activity    <= 1'b1;
                        sd_cs       <= 1'b0;
                        cmd_num     <= 6'd24;
                        cmd_arg     <= card_address(req_lba);
                        cmd_crc     <= 8'hFF;
                        cmd_index   <= 0;
                        cmd_next    <= ST_AFTER_CMD24;
                        poll_count  <= 0;
                        byte_active <= 1'b0;
                        state       <= ST_CMD_SEND;
                    end
                end

                // --------------------------------------------------------
                // CMD17 single-block read
                // --------------------------------------------------------
                ST_AFTER_CMD17: begin
                    if (r1 != 8'h00) begin
                        state <= ST_ERROR;
                    end
                    else begin
                        poll_count  <= 0;
                        byte_active <= 1'b0;
                        state <= ST_READ_TOKEN;
                    end
                end

                ST_READ_TOKEN: begin
                    if (!byte_active) begin
                        spi_tx      <= 8'hFF;
                        spi_start   <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        if (spi_rx == 8'hFE) begin
                            data_index <= 0;
                            state <= ST_READ_DATA;
                        end
                        else if (poll_count >= 24'd2_000_000) begin
                            state <= ST_ERROR;
                        end
                        else begin
                            poll_count <= poll_count + 1'b1;
                        end
                    end
                end

                ST_READ_DATA: begin
                    if (!byte_active) begin
                        spi_tx      <= 8'hFF;
                        spi_start   <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        block_buf[data_index] <= spi_rx;
                        if (data_index == 9'd511) begin
                            state <= ST_READ_CRC1;
                        end
                        else begin
                            data_index <= data_index + 1'b1;
                        end
                    end
                end

                ST_READ_CRC1: begin
                    if (!byte_active) begin
                        spi_tx <= 8'hFF; spi_start <= 1'b1; byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        state <= ST_READ_CRC2;
                    end
                end

                ST_READ_CRC2: begin
                    if (!byte_active) begin
                        spi_tx <= 8'hFF; spi_start <= 1'b1; byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        gap_next <= ST_FINISH_READ;
                        state <= ST_GAP;
                    end
                end

                ST_FINISH_READ: begin
                    busy  <= 1'b0;
                    done  <= 1'b1;
                    state <= ST_READY;
                end

                // --------------------------------------------------------
                // CMD24 single-block write
                // --------------------------------------------------------
                ST_AFTER_CMD24: begin
                    if (r1 != 8'h00) begin
                        state <= ST_ERROR;
                    end
                    else begin
                        byte_active <= 1'b0;
                        state <= ST_WRITE_PRETOKEN;
                    end
                end

                ST_WRITE_PRETOKEN: begin
                    if (!byte_active) begin
                        spi_tx <= 8'hFF; spi_start <= 1'b1; byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        state <= ST_WRITE_TOKEN;
                    end
                end

                ST_WRITE_TOKEN: begin
                    if (!byte_active) begin
                        spi_tx <= 8'hFE; spi_start <= 1'b1; byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        data_index <= 0;
                        state <= ST_WRITE_DATA;
                    end
                end

                ST_WRITE_DATA: begin
                    if (!byte_active) begin
                        spi_tx      <= block_buf[data_index];
                        spi_start   <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        if (data_index == 9'd511) begin
                            state <= ST_WRITE_CRC1;
                        end
                        else begin
                            data_index <= data_index + 1'b1;
                        end
                    end
                end

                ST_WRITE_CRC1: begin
                    if (!byte_active) begin
                        spi_tx <= 8'hFF; spi_start <= 1'b1; byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        state <= ST_WRITE_CRC2;
                    end
                end

                ST_WRITE_CRC2: begin
                    if (!byte_active) begin
                        spi_tx <= 8'hFF; spi_start <= 1'b1; byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;

                        // Stage 7.4 WRITE FIX:
                        // A card may return one or more FF wait bytes before
                        // the CMD24 data-response token.
                        poll_count <= 0;
                        state <= ST_WRITE_RESPONSE;
                    end
                end

                ST_WRITE_RESPONSE: begin
                    if (!byte_active) begin
                        spi_tx <= 8'hFF;
                        spi_start <= 1'b1;
                        byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;

                        if ((spi_rx & 8'h1F) == 8'h05) begin
                            // Data accepted.
                            poll_count <= 0;
                            state <= ST_WRITE_BUSY;
                        end
                        else if (spi_rx == 8'hFF) begin
                            // Card has not supplied its response yet.
                            // Keep clocking instead of permanently wedging.
                            if (poll_count >= 24'd1_000_000)
                                state <= ST_ERROR;
                            else
                                poll_count <= poll_count + 1'b1;
                        end
                        else begin
                            // 0x0B = CRC reject, 0x0D = write reject, etc.
                            state <= ST_ERROR;
                        end
                    end
                end

                ST_WRITE_BUSY: begin
                    if (!byte_active) begin
                        spi_tx <= 8'hFF; spi_start <= 1'b1; byte_active <= 1'b1;
                    end
                    else if (spi_done) begin
                        byte_active <= 1'b0;
                        if (spi_rx == 8'hFF) begin
                            gap_next <= ST_FINISH_WRITE;
                            state <= ST_GAP;
                        end
                        else if (poll_count >= 24'd4_000_000) begin
                            state <= ST_ERROR;
                        end
                        else begin
                            poll_count <= poll_count + 1'b1;
                        end
                    end
                end

                ST_FINISH_WRITE: begin
                    busy  <= 1'b0;
                    done  <= 1'b1;
                    state <= ST_READY;
                end

                ST_ERROR: begin
                    sd_cs <= 1'b1;
                    ready <= 1'b0;
                    // If an in-flight transaction failed, give the DCDD one
                    // completion pulse so it can clear its internal request.
                    if (busy)
                        done <= 1'b1;
                    busy  <= 1'b0;
                    error <= 1'b1;
                    // Stay here until reset; setup console can report it.
                end

                default: state <= ST_ERROR;
            endcase
        end
    end

endmodule
