`timescale 1ns/1ps

module stage7_uart_tx_byte #(
    parameter integer CLOCK_HZ = 100000000,
    parameter integer BAUD     = 115200
) (
    input  wire       clk,
    input  wire       reset,
    input  wire       start,
    input  wire [7:0] data,
    output wire       tx,
    output reg        busy,
    output reg        done
);
    localparam integer CLKS_PER_BIT = CLOCK_HZ / BAUD;
    reg [9:0]  shift;
    reg [15:0] count;
    reg [3:0]  bitno;
    assign tx = busy ? shift[bitno] : 1'b1;

    always @(posedge clk) begin
        done <= 1'b0;
        if (reset) begin
            busy <= 1'b0; shift <= 10'h3FF; count <= 0; bitno <= 0;
        end else if (!busy) begin
            if (start) begin
                shift <= {1'b1, data, 1'b0};
                count <= 0; bitno <= 0; busy <= 1'b1;
            end
        end else if (count == CLKS_PER_BIT-1) begin
            count <= 0;
            if (bitno == 9) begin
                bitno <= 0; busy <= 1'b0; done <= 1'b1;
            end else begin
                bitno <= bitno + 1'b1;
            end
        end else begin
            count <= count + 1'b1;
        end
    end
endmodule

module stage7_uart_rx_byte #(
    parameter integer CLOCK_HZ = 100000000,
    parameter integer BAUD     = 115200
) (
    input  wire       clk,
    input  wire       reset,
    input  wire       rx,
    output reg  [7:0] data,
    output reg        valid
);
    localparam integer CLKS_PER_BIT = CLOCK_HZ / BAUD;
    localparam integer HALF_BIT = CLKS_PER_BIT / 2;
    localparam [1:0] RX_IDLE=0, RX_START=1, RX_DATA=2, RX_STOP=3;
    reg rx_meta, rx_sync;
    reg [1:0] state;
    reg [15:0] count;
    reg [2:0] bitno;
    reg [7:0] shift;

    always @(posedge clk) begin
        rx_meta <= rx;
        rx_sync <= rx_meta;
    end

    always @(posedge clk) begin
        valid <= 1'b0;
        if (reset) begin
            state <= RX_IDLE; count <= 0; bitno <= 0; shift <= 0; data <= 0;
        end else begin
            case (state)
                RX_IDLE: if (!rx_sync) begin count <= HALF_BIT; state <= RX_START; end
                RX_START: begin
                    if (count == 0) begin
                        if (!rx_sync) begin count <= CLKS_PER_BIT-1; bitno <= 0; state <= RX_DATA; end
                        else state <= RX_IDLE;
                    end else count <= count - 1'b1;
                end
                RX_DATA: begin
                    if (count == 0) begin
                        shift[bitno] <= rx_sync; count <= CLKS_PER_BIT-1;
                        if (bitno == 7) state <= RX_STOP;
                        else bitno <= bitno + 1'b1;
                    end else count <= count - 1'b1;
                end
                RX_STOP: begin
                    if (count == 0) begin data <= shift; valid <= 1'b1; state <= RX_IDLE; end
                    else count <= count - 1'b1;
                end
                default: state <= RX_IDLE;
            endcase
        end
    end
endmodule

// ============================================================
// MILO Altair 8800 — Stage 7.2 persistent firmware setup
//
// Reserved setup block: microSD LBA 64.
// A: begins at LBA 2048, so this never overlaps CP/M drives.
// X = Save & Exit, Q = Discard & Exit.
// A: boot-disk preflight is completed before DBL is released.
// ============================================================
module altair_boot_setup (
    input  wire       clk,
    input  wire       reset,
    input  wire       uart_rx,
    output wire       uart_tx,

    input  wire       sd_ready,
    input  wire       sd_busy,
    input  wire       sd_done,
    input  wire       sd_error,
    input  wire       sd_high_capacity,

    output reg        cfg_sd_req_read,
    output reg        cfg_sd_req_write,
    output reg [31:0] cfg_sd_lba,
    output reg [8:0]  cfg_buf_addr,
    input  wire [7:0] cfg_buf_dout,
    output reg        cfg_buf_we,
    output reg [7:0]  cfg_buf_din,

    output reg        boot_go,
    output reg [2:0]  speed_sel,
    output reg        write_protect
);
    `include "boot_messages.vh"

    localparam [31:0] CONFIG_LBA = 32'd64;
    localparam [31:0] BOOT_A_LBA = 32'd2048;

    reg [7:0] msg_rom [0:4095];
    initial begin
        $readmemh("memory/STAGE7_BOOT_MENU.mem", msg_rom);
    end

    reg tx_start;
    reg [7:0] tx_data;
    wire tx_busy, tx_done;
    stage7_uart_tx_byte tx0(
        .clk(clk), .reset(reset), .start(tx_start), .data(tx_data),
        .tx(uart_tx), .busy(tx_busy), .done(tx_done)
    );

    wire [7:0] rx_data;
    wire rx_valid;
    stage7_uart_rx_byte rx0(
        .clk(clk), .reset(reset), .rx(uart_rx),
        .data(rx_data), .valid(rx_valid)
    );

    reg [11:0] msg_ptr, msg_remaining;
    reg msg_active, sender_wait;

    reg [2:0] saved_speed, edit_speed;
    reg saved_wp, edit_wp;
    reg config_valid, boot_disk_ok;
    reg [7:0] cfg_bytes [0:15];

    reg [5:0] ctrl_state;
    localparam [5:0]
      C_SETTLE=0, C_WELCOME_WAIT=1, C_CFG_WAIT_SD=2, C_CFG_READ_WAIT=3,
      C_CFG_PARSE=4, C_CFG_VALIDATE=5, C_PREFLIGHT_REQ=6, C_PREFLIGHT_WAIT=7,
      C_STATS=8, C_WAITKEY=9, C_MENU_PRINT=10, C_MENU_WAIT=11, C_MENU=12,
      C_SAVE_FILL=13, C_SAVE_REQ=14, C_SAVE_WAIT=15, C_SAVE_MSG=16,
      C_DISCARD_MSG=17, C_BOOT_MSG=18, C_ERROR_HOLD=19, C_BOOTED=20;

    reg [28:0] timer;
    reg [23:0] settle_timer;
    reg [4:0] parse_index, fill_index;
    reg parse_armed;
    reg [3:0] stats_step;
    reg stats_for_menu;

    task automatic queue_msg;
        input integer off;
        input integer len;
        begin
            msg_ptr <= off[11:0];
            msg_remaining <= len[11:0];
            msg_active <= 1'b1;
            sender_wait <= 1'b0;
        end
    endtask

    task automatic queue_speed;
        input [2:0] sel;
        begin
            case (sel)
                3'd0: queue_msg(MSG_SPEED2_OFF, MSG_SPEED2_LEN);
                3'd1: queue_msg(MSG_SPEED4_OFF, MSG_SPEED4_LEN);
                3'd2: queue_msg(MSG_SPEED8_OFF, MSG_SPEED8_LEN);
                3'd3: queue_msg(MSG_SPEED16_OFF, MSG_SPEED16_LEN);
                default: queue_msg(MSG_SPEED25_OFF, MSG_SPEED25_LEN);
            endcase
        end
    endtask

    function automatic [7:0] cfg_write_byte;
        input [4:0] idx;
        begin
            case (idx)
                0:  cfg_write_byte = "M";
                1:  cfg_write_byte = "I";
                2:  cfg_write_byte = "L";
                3:  cfg_write_byte = "O";
                4:  cfg_write_byte = "8";
                5:  cfg_write_byte = "8";
                6:  cfg_write_byte = "0";
                7:  cfg_write_byte = "0";
                8:  cfg_write_byte = 8'h01;
                9:  cfg_write_byte = {5'b0,edit_speed};
                10: cfg_write_byte = {7'b0,edit_wp};
                11: cfg_write_byte = ({5'b0,edit_speed}^{7'b0,edit_wp}^8'hA5);
                12: cfg_write_byte = "C";
                13: cfg_write_byte = "F";
                14: cfg_write_byte = "G";
                15: cfg_write_byte = "1";
                default: cfg_write_byte = 8'h00;
            endcase
        end
    endfunction

    function automatic cfg_valid_now;
        begin
            cfg_valid_now =
                cfg_bytes[0]=="M" && cfg_bytes[1]=="I" &&
                cfg_bytes[2]=="L" && cfg_bytes[3]=="O" &&
                cfg_bytes[4]=="8" && cfg_bytes[5]=="8" &&
                cfg_bytes[6]=="0" && cfg_bytes[7]=="0" &&
                cfg_bytes[8]==8'h01 &&
                cfg_bytes[9] <= 8'd4 &&
                cfg_bytes[10] <= 8'd1 &&
                cfg_bytes[11] == (cfg_bytes[9]^cfg_bytes[10]^8'hA5) &&
                cfg_bytes[12]=="C" && cfg_bytes[13]=="F" &&
                cfg_bytes[14]=="G" && cfg_bytes[15]=="1";
        end
    endfunction

    integer k;
    always @(posedge clk) begin
        tx_start <= 1'b0;
        cfg_sd_req_read <= 1'b0;
        cfg_sd_req_write <= 1'b0;
        cfg_buf_we <= 1'b0;

        if (reset) begin
            boot_go <= 1'b0;
            speed_sel <= 3'd0;
            write_protect <= 1'b0;

            saved_speed <= 3'd0; edit_speed <= 3'd0;
            saved_wp <= 1'b0; edit_wp <= 1'b0;
            config_valid <= 1'b0; boot_disk_ok <= 1'b0;

            msg_ptr <= 0; msg_remaining <= 0; msg_active <= 1'b0; sender_wait <= 1'b0;
            tx_data <= 8'hFF;

            cfg_sd_lba <= CONFIG_LBA;
            cfg_buf_addr <= 0;
            cfg_buf_din <= 0;

            ctrl_state <= C_SETTLE;
            timer <= 0; settle_timer <= 0;
            parse_index <= 0; fill_index <= 0; parse_armed <= 1'b0;
            stats_step <= 0; stats_for_menu <= 1'b0;
            for (k=0;k<16;k=k+1) cfg_bytes[k] <= 0;
        end else begin
            // Message sender.
            if (msg_active) begin
                if (!sender_wait && !tx_busy) begin
                    tx_data <= msg_rom[msg_ptr];
                    tx_start <= 1'b1;
                    sender_wait <= 1'b1;
                end else if (sender_wait && tx_done) begin
                    sender_wait <= 1'b0;
                    if (msg_remaining <= 1) begin
                        msg_remaining <= 0;
                        msg_active <= 1'b0;
                    end else begin
                        msg_ptr <= msg_ptr + 1'b1;
                        msg_remaining <= msg_remaining - 1'b1;
                    end
                end
            end

            case (ctrl_state)
                C_SETTLE: begin
                    if (settle_timer >= 24'd10_000_000) begin
                        queue_msg(MSG_WELCOME_OFF, MSG_WELCOME_LEN);
                        ctrl_state <= C_WELCOME_WAIT;
                    end else settle_timer <= settle_timer + 1'b1;
                end

                C_WELCOME_WAIT: if (!msg_active) ctrl_state <= C_CFG_WAIT_SD;

                C_CFG_WAIT_SD: begin
                    if (sd_error) begin
                        queue_msg(MSG_SD_FATAL_OFF, MSG_SD_FATAL_LEN);
                        ctrl_state <= C_ERROR_HOLD;
                    end else if (sd_ready && !sd_busy) begin
                        cfg_sd_lba <= CONFIG_LBA;
                        cfg_sd_req_read <= 1'b1;
                        ctrl_state <= C_CFG_READ_WAIT;
                    end
                end

                C_CFG_READ_WAIT: if (sd_done) begin
                    if (sd_error) begin
                        queue_msg(MSG_SD_FATAL_OFF, MSG_SD_FATAL_LEN);
                        ctrl_state <= C_ERROR_HOLD;
                    end else begin
                        parse_index <= 0;
                        parse_armed <= 1'b0;
                        ctrl_state <= C_CFG_PARSE;
                    end
                end

                C_CFG_PARSE: begin
                    if (!parse_armed) begin
                        cfg_buf_addr <= {4'b0000, parse_index};
                        parse_armed <= 1'b1;
                    end else begin
                        cfg_bytes[parse_index] <= cfg_buf_dout;
                        parse_armed <= 1'b0;
                        if (parse_index == 15) ctrl_state <= C_CFG_VALIDATE;
                        else parse_index <= parse_index + 1'b1;
                    end
                end

                C_CFG_VALIDATE: begin
                    if (cfg_valid_now()) begin
                        saved_speed <= cfg_bytes[9][2:0];
                        edit_speed <= cfg_bytes[9][2:0];
                        speed_sel <= cfg_bytes[9][2:0];
                        saved_wp <= cfg_bytes[10][0];
                        edit_wp <= cfg_bytes[10][0];
                        write_protect <= cfg_bytes[10][0];
                        config_valid <= 1'b1;
                    end else begin
                        saved_speed <= 3'd0; edit_speed <= 3'd0; speed_sel <= 3'd0;
                        saved_wp <= 1'b0; edit_wp <= 1'b0; write_protect <= 1'b0;
                        config_valid <= 1'b0;
                    end
                    ctrl_state <= C_PREFLIGHT_REQ;
                end

                C_PREFLIGHT_REQ: if (sd_ready && !sd_busy) begin
                    cfg_sd_lba <= BOOT_A_LBA;
                    cfg_sd_req_read <= 1'b1;
                    ctrl_state <= C_PREFLIGHT_WAIT;
                end

                C_PREFLIGHT_WAIT: if (sd_done) begin
                    if (sd_error) begin
                        boot_disk_ok <= 1'b0;
                        queue_msg(MSG_PREFLIGHT_FAIL_OFF, MSG_PREFLIGHT_FAIL_LEN);
                        ctrl_state <= C_ERROR_HOLD;
                    end else begin
                        boot_disk_ok <= 1'b1;
                        stats_step <= 0;
                        stats_for_menu <= 1'b0;
                        ctrl_state <= C_STATS;
                    end
                end

                // Stats sequence.
                C_STATS: if (!msg_active) begin
                    case (stats_step)
                        0: begin queue_msg(MSG_STATS_HEAD_OFF,MSG_STATS_HEAD_LEN); stats_step<=1; end
                        1: begin queue_speed(stats_for_menu?edit_speed:speed_sel); stats_step<=2; end
                        2: begin
                            if (sd_error) queue_msg(MSG_SD_ERROR_OFF,MSG_SD_ERROR_LEN);
                            else if (!sd_ready) queue_msg(MSG_SD_INIT_OFF,MSG_SD_INIT_LEN);
                            else if (sd_high_capacity) queue_msg(MSG_SD_SDHC_OFF,MSG_SD_SDHC_LEN);
                            else queue_msg(MSG_SD_SDSC_OFF,MSG_SD_SDSC_LEN);
                            stats_step<=3;
                        end
                        3: begin
                            if (boot_disk_ok) queue_msg(MSG_BOOTDISK_OK_OFF,MSG_BOOTDISK_OK_LEN);
                            else queue_msg(MSG_BOOTDISK_BAD_OFF,MSG_BOOTDISK_BAD_LEN);
                            stats_step<=4;
                        end
                        4: begin
                            if (stats_for_menu?edit_wp:write_protect)
                                queue_msg(MSG_WRITE_SAFE_OFF,MSG_WRITE_SAFE_LEN);
                            else queue_msg(MSG_WRITE_ON_OFF,MSG_WRITE_ON_LEN);
                            stats_step<=5;
                        end
                        5: begin queue_msg(MSG_DRIVES_OFF,MSG_DRIVES_LEN); stats_step<=6; end
                        6: begin
                            if (config_valid) queue_msg(MSG_CFG_SAVED_OFF,MSG_CFG_SAVED_LEN);
                            else queue_msg(MSG_CFG_DEFAULT_OFF,MSG_CFG_DEFAULT_LEN);
                            stats_step<=7;
                        end
                        7: begin
                            if (stats_for_menu) ctrl_state<=C_MENU_PRINT;
                            else begin
                                queue_msg(MSG_DEL_PROMPT_OFF,MSG_DEL_PROMPT_LEN);
                                timer <= 0; stats_step<=8;
                            end
                        end
                        default: ctrl_state<=C_WAITKEY;
                    endcase
                end

                C_WAITKEY: if (!msg_active) begin
                    if (rx_valid && (rx_data==8'h7F || rx_data==8'h1B)) begin
                        edit_speed<=saved_speed; edit_wp<=saved_wp;
                        ctrl_state<=C_MENU_PRINT;
                    end else if (timer >= 29'd500_000_000) begin
                        speed_sel<=saved_speed; write_protect<=saved_wp;
                        queue_msg(MSG_BOOT_OFF,MSG_BOOT_LEN);
                        ctrl_state<=C_BOOT_MSG;
                    end else timer<=timer+1'b1;
                end

                C_MENU_PRINT: if (!msg_active) begin
                    queue_msg(MSG_MENU_OFF,MSG_MENU_LEN);
                    ctrl_state<=C_MENU_WAIT;
                end
                C_MENU_WAIT: if (!msg_active) ctrl_state<=C_MENU;

                C_MENU: if (!msg_active && rx_valid) begin
                    case (rx_data)
                        "1": begin edit_speed<=0; queue_msg(MSG_PENDING_2_OFF,MSG_PENDING_2_LEN); ctrl_state<=C_MENU_WAIT; end
                        "2": begin edit_speed<=1; queue_msg(MSG_PENDING_4_OFF,MSG_PENDING_4_LEN); ctrl_state<=C_MENU_WAIT; end
                        "3": begin edit_speed<=2; queue_msg(MSG_PENDING_8_OFF,MSG_PENDING_8_LEN); ctrl_state<=C_MENU_WAIT; end
                        "4": begin edit_speed<=3; queue_msg(MSG_PENDING_16_OFF,MSG_PENDING_16_LEN); ctrl_state<=C_MENU_WAIT; end
                        "5": begin edit_speed<=4; queue_msg(MSG_PENDING_25_OFF,MSG_PENDING_25_LEN); ctrl_state<=C_MENU_WAIT; end
                        "w","W": begin
                            edit_wp <= ~edit_wp;
                            if (!edit_wp) queue_msg(MSG_PENDING_SAFE_OFF,MSG_PENDING_SAFE_LEN);
                            else queue_msg(MSG_PENDING_WRITE_OFF,MSG_PENDING_WRITE_LEN);
                            ctrl_state<=C_MENU_WAIT;
                        end
                        "s","S": begin
                            stats_step<=0; stats_for_menu<=1'b1; ctrl_state<=C_STATS;
                        end
                        "x","X": begin
                            if (!sd_ready || sd_busy || sd_error) begin
                                queue_msg(MSG_SAVE_FAIL_OFF,MSG_SAVE_FAIL_LEN);
                                ctrl_state<=C_MENU_WAIT;
                            end else begin
                                fill_index<=0;
                                ctrl_state<=C_SAVE_FILL;
                            end
                        end
                        "q","Q": begin
                            if (!boot_disk_ok || sd_error) begin
                                queue_msg(MSG_PREFLIGHT_FAIL_OFF,MSG_PREFLIGHT_FAIL_LEN);
                                ctrl_state<=C_ERROR_HOLD;
                            end else begin
                                edit_speed<=saved_speed; edit_wp<=saved_wp;
                                speed_sel<=saved_speed; write_protect<=saved_wp;
                                queue_msg(MSG_DISCARD_OFF,MSG_DISCARD_LEN);
                                ctrl_state<=C_DISCARD_MSG;
                            end
                        end
                        default: begin queue_msg(MSG_BAD_OFF,MSG_BAD_LEN); ctrl_state<=C_MENU_WAIT; end
                    endcase
                end

                C_SAVE_FILL: if (!sd_busy) begin
                    cfg_buf_addr <= {4'b0000, fill_index};
                    cfg_buf_din <= cfg_write_byte(fill_index);
                    cfg_buf_we <= 1'b1;
                    if (fill_index==15) ctrl_state<=C_SAVE_REQ;
                    else fill_index<=fill_index+1'b1;
                end

                C_SAVE_REQ: if (!sd_busy) begin
                    cfg_sd_lba<=CONFIG_LBA;
                    cfg_sd_req_write<=1'b1;
                    ctrl_state<=C_SAVE_WAIT;
                end

                C_SAVE_WAIT: if (sd_done) begin
                    if (sd_error) begin
                        queue_msg(MSG_SAVE_FAIL_OFF,MSG_SAVE_FAIL_LEN);
                        ctrl_state<=C_MENU_WAIT;
                    end else begin
                        saved_speed<=edit_speed; speed_sel<=edit_speed;
                        saved_wp<=edit_wp; write_protect<=edit_wp;
                        config_valid<=1'b1;
                        queue_msg(MSG_SAVE_OK_OFF,MSG_SAVE_OK_LEN);
                        ctrl_state<=C_SAVE_MSG;
                    end
                end

                C_SAVE_MSG: if (!msg_active) begin
                    queue_msg(MSG_BOOT_OFF,MSG_BOOT_LEN); ctrl_state<=C_BOOT_MSG;
                end

                C_DISCARD_MSG: if (!msg_active) begin
                    queue_msg(MSG_BOOT_OFF,MSG_BOOT_LEN); ctrl_state<=C_BOOT_MSG;
                end

                C_BOOT_MSG: if (!msg_active) begin
                    boot_go<=1'b1; ctrl_state<=C_BOOTED;
                end

                C_ERROR_HOLD: if (!msg_active && rx_valid && (rx_data=="s" || rx_data=="S")) begin
                    stats_step<=0; stats_for_menu<=1'b1; ctrl_state<=C_STATS;
                end

                C_BOOTED: boot_go<=1'b1;
                default: ctrl_state<=C_SETTLE;
            endcase
        end
    end
endmodule
