module altair_2sio_uart
#(
    parameter integer CLOCK_HZ = 100000000,
    parameter integer BAUD     = 115200
)
(
    input  wire       clk,
    input  wire       reset,

    input  wire       io_rd_start,
    input  wire       io_wr_start,

    input  wire [7:0] port,
    input  wire [7:0] cpu_dout,

    output reg  [7:0] cpu_din,

    input  wire       uart_rx,
    output wire       uart_tx,

    output reg  [7:0] control_reg,
    output reg        tx_activity,
    output reg        rx_activity
);

    localparam integer CLKS_PER_BIT =
        CLOCK_HZ / BAUD;

    localparam integer HALF_BIT =
        CLKS_PER_BIT / 2;


    // ========================================================
    // UART TRANSMITTER
    // ========================================================

    reg        tx_busy;
    reg [9:0]  tx_shift;
    reg [15:0] tx_count;
    reg [3:0]  tx_bit;

    assign uart_tx =
        tx_busy ? tx_shift[tx_bit] : 1'b1;


    always @(posedge clk) begin

        tx_activity <= 1'b0;

        if (reset) begin

            tx_busy  <= 1'b0;
            tx_shift <= 10'h3FF;
            tx_count <= 0;
            tx_bit   <= 0;

        end
        else begin

            if (!tx_busy &&
                io_wr_start &&
                port == 8'h11) begin

                // 8N1:
                //
                // bit 0 = start
                // bits 1-8 = data
                // bit 9 = stop

                tx_shift <= {
                    1'b1,
                    cpu_dout,
                    1'b0
                };

                tx_count <= 0;
                tx_bit   <= 0;
                tx_busy  <= 1'b1;

                tx_activity <= 1'b1;

            end
            else if (tx_busy) begin

                if (tx_count ==
                    CLKS_PER_BIT - 1) begin

                    tx_count <= 0;

                    if (tx_bit == 9) begin
                        tx_busy <= 1'b0;
                        tx_bit  <= 0;
                    end
                    else begin
                        tx_bit <= tx_bit + 1'b1;
                    end

                end
                else begin
                    tx_count <= tx_count + 1'b1;
                end

            end

        end
    end


    // ========================================================
    // UART RECEIVER
    // ========================================================

    reg rx_meta;
    reg rx_sync;

    always @(posedge clk) begin
        rx_meta <= uart_rx;
        rx_sync <= rx_meta;
    end


    localparam [1:0]
        RX_IDLE  = 2'd0,
        RX_START = 2'd1,
        RX_DATA  = 2'd2,
        RX_STOP  = 2'd3;

    reg [1:0]  rx_state;
    reg [15:0] rx_count;
    reg [2:0]  rx_bit;
    reg [7:0]  rx_shift;

    reg [7:0] rx_data_reg;
    reg       rx_full;


    always @(posedge clk) begin

        rx_activity <= 1'b0;

        if (reset) begin

            rx_state    <= RX_IDLE;
            rx_count    <= 0;
            rx_bit      <= 0;
            rx_shift    <= 0;
            rx_data_reg <= 0;
            rx_full     <= 1'b0;

        end
        else begin

            // CPU consumed receive byte.
            if (io_rd_start &&
                port == 8'h11) begin

                rx_full <= 1'b0;

            end


            case (rx_state)

                RX_IDLE: begin

                    if (!rx_sync) begin
                        rx_count <= HALF_BIT;
                        rx_state <= RX_START;
                    end

                end


                RX_START: begin

                    if (rx_count == 0) begin

                        if (!rx_sync) begin

                            rx_count <=
                                CLKS_PER_BIT - 1;

                            rx_bit   <= 0;
                            rx_state <= RX_DATA;

                        end
                        else begin
                            rx_state <= RX_IDLE;
                        end

                    end
                    else begin
                        rx_count <= rx_count - 1'b1;
                    end

                end


                RX_DATA: begin

                    if (rx_count == 0) begin

                        rx_shift[rx_bit] <= rx_sync;

                        rx_count <=
                            CLKS_PER_BIT - 1;

                        if (rx_bit == 7) begin
                            rx_state <= RX_STOP;
                        end
                        else begin
                            rx_bit <= rx_bit + 1'b1;
                        end

                    end
                    else begin
                        rx_count <= rx_count - 1'b1;
                    end

                end


                RX_STOP: begin

                    if (rx_count == 0) begin

                        rx_data_reg <= rx_shift;
                        rx_full     <= 1'b1;

                        rx_activity <= 1'b1;

                        rx_state <= RX_IDLE;

                    end
                    else begin
                        rx_count <= rx_count - 1'b1;
                    end

                end


                default:
                    rx_state <= RX_IDLE;

            endcase

        end
    end


    // ========================================================
    // MITS 88-2SIO / MC6850 REGISTER VIEW
    //
    // 10h = control/status
    // 11h = data
    //
    // status bit 0 = receive full
    // status bit 1 = transmit empty
    // ========================================================

    always @(*) begin

        case (port)

            8'h10:
                cpu_din = {
                    6'b000000,
                    ~tx_busy,
                    rx_full
                };

            8'h11:
                cpu_din = rx_data_reg;

            default:
                cpu_din = 8'hFF;

        endcase

    end


    always @(posedge clk) begin

        if (reset) begin

            control_reg <= 8'h00;

        end
        else if (io_wr_start &&
                 port == 8'h10) begin

            control_reg <= cpu_dout;

        end

    end

endmodule
