module altair_ram64k
(
    input  wire        clk,
    input  wire [15:0] addr,
    input  wire [7:0]  din,
    input  wire        we,
    output wire [7:0]  dout
);

    (* ram_style = "block" *)
    reg [7:0] mem [0:65535];

    reg [7:0] q;

    initial begin
        $readmemh(
            "memory/RAM_INIT.mem",
            mem
        );
    end

    always @(posedge clk) begin

        q <= mem[addr];

        // FF00-FFFF is our MITS DBL PROM area.
        if (we && addr < 16'hFF00)
            mem[addr] <= din;

    end

    assign dout = q;

endmodule
