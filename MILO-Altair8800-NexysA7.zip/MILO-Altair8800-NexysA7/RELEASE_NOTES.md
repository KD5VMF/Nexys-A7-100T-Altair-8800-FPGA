# Stage 7.4 Current Release Notes

## Current release identity

This package was assembled from the authoritative working tree on `milo-brain` on September 13, 2026.

Current source features include:

- Stage 7.4 MAX STORAGE architecture
- 56K CP/M 2.2b Altair 8 MB Virtual Drive boot
- persistent setup/configuration stored on microSD
- authentic MITS DBL bootstrap held at 2 MHz
- selectable 2 / 4 / 8 / 16 / 25 MHz runtime CPU speeds
- CMD24 SD-card write-response polling fix
- inverted live A0-A15 address LEDs
- blue RGB disk-activity LED
- autonomous QSPI x4 boot

## Prebuilt release binary

The packaged BIT contains the Vivado build timestamp:

```text
2026/09/13 17:40:10
```

SHA256:

```text
BIT  462630e9423033e7e974aeb0d104c47d2ec0f5ced114a751d78065516ba1a7ea
MCS  9952a07c9e7a010fa9c83058438dab1f45b5e69b1b260f48afce7d937661d503
```

The packaged route timing report passes setup timing with positive slack (worst reported setup slack 0.299 ns).

## Known-good operating observations

- CP/M boots to `A0>`.
- A: reports 7940k free.
- B: reports 8168k free.
- 16 MHz runtime selection is noticeably faster and works.
- Setup settings persist across cold boot.

## Remaining validation

- Occasional cold-boot lockup has been observed.
- The latest SD write-path change should receive extended hardware write/stress testing.
- C: and D: remain the preserved smaller legacy disks in this Stage 7.4 layout.

The recovery image and release binaries should be retained while those final issues are investigated.
