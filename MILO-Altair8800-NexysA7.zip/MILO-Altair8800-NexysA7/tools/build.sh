#!/usr/bin/env bash
set -Eeuo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO"
VIVADO_SETTINGS="${VIVADO_SETTINGS:-/data/fpga/AMD/2026.1/Vivado/settings64.sh}"
[[ -f "$VIVADO_SETTINGS" ]] || { echo "Vivado settings not found: $VIVADO_SETTINGS"; exit 1; }
source "$VIVADO_SETTINGS"
vivado -mode batch -source "$REPO/build/build.tcl" 2>&1 | tee "$REPO/build-latest.log"
