#!/usr/bin/env bash
set -Eeuo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO"
VIVADO_SETTINGS="${VIVADO_SETTINGS:-/data/fpga/AMD/2026.1/Vivado/settings64.sh}"
[[ -f "$VIVADO_SETTINGS" ]] || { echo "Vivado settings not found: $VIVADO_SETTINGS"; exit 1; }
source "$VIVADO_SETTINGS"
lsusb | grep -q '0403:6010' || { echo 'Nexys J6 FT2232 (0403:6010) not found.'; exit 1; }
pkill -f hw_server 2>/dev/null || true
pkill -f cs_server 2>/dev/null || true
sleep 2
vivado -mode batch -source "$REPO/build/flash-qspi.tcl" 2>&1 | tee "$REPO/flash-latest.log"
