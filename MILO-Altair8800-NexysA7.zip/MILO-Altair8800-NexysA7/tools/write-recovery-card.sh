#!/usr/bin/env bash
set -Eeuo pipefail
[[ $# -eq 1 ]] || { echo "Usage: $0 /dev/sdX"; exit 2; }
DEV="$1"
HERE="$(cd "$(dirname "$0")/.." && pwd)"
IMG="$HERE/recovery/current-card-first80MiB.img"
[[ -b "$DEV" ]] || { echo "Not a block device: $DEV"; exit 1; }
[[ -f "$IMG" ]] || { echo "Recovery image missing: $IMG"; exit 1; }
echo "THIS OVERWRITES THE FIRST 80 MiB OF $DEV"
read -r -p "Type YES to continue: " x
[[ "$x" == YES ]] || exit 1
sudo dd if="$IMG" of="$DEV" bs=4M count=20 status=progress conv=fsync
sync
EXP="$(sha256sum "$IMG" | awk '{print $1}')"
GOT="$(sudo dd if="$DEV" bs=4M count=20 status=none | sha256sum | awk '{print $1}')"
echo "EXPECTED=$EXP"
echo "READBACK =$GOT"
[[ "$EXP" == "$GOT" ]] || { echo "VERIFY FAILED"; exit 1; }
echo "RECOVERY_CARD_WRITE_VERIFY=PASS"
