# Current Status

## 95% perfect baseline

Confirmed working:

- Nexys A7 autonomous QSPI boot
- persistent setup menu
- authentic MITS DBL bootstrap at 2 MHz
- 56K CP/M 2.2b v1.0
- Altair 8 MB Virtual Drive system
- A: reports 7940k free
- B: reports 8168k free
- 16 MHz runtime works and is noticeably faster
- current source has inverted address LEDs
- current source has CMD24 response-token polling fix

## Known remaining issues

- Occasional boot lockup is still observed.
- The latest SD write-path fix requires final hardware stress validation.
- C: and D: remain the smaller preserved drives in the current Stage 7.4 design.

Do not delete the known-good recovery image or release BIT/MCS while investigating remaining issues.
