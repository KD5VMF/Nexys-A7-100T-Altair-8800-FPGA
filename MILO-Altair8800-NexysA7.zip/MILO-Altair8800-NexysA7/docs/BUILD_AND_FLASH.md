# Build and Flash

## Host

Known build environment:

- Ubuntu 24.04
- AMD Vivado 2026.1
- Nexys A7-100T (`xc7a100tcsg324-1`)

## Build

```bash
source /data/fpga/AMD/2026.1/Vivado/settings64.sh
vivado -mode batch -source ~/fpga/mits-altair8800/stage7/build/build.tcl
```

The build script is fail-closed on negative timing slack.

## Flash

Connect J6 PROG/UART and confirm:

```bash
lsusb | grep 0403:6010
```

Then:

```bash
source /data/fpga/AMD/2026.1/Vivado/settings64.sh
vivado -mode batch \
  -source ~/fpga/mits-altair8800/stage7/build/flash-qspi.tcl
```

Expected:

```text
STAGE7_QSPI_FLASH_VERIFY=PASS
```

Cold power-cycle the board.
