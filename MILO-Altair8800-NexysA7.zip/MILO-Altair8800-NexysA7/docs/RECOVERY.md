# Recovery

The repository contains three independent recovery layers when available:

1. Current HDL/build sources.
2. Current verified QSPI `.bit` and `.mcs`.
3. Exact first 80 MiB of the current Stage 7.4 microSD.

## Restore the FPGA

Use `release/milo-altair8800-stage7-final-qspi-x4.mcs` with the supplied `build/flash-qspi.tcl`.

## Restore the card

Use:

```bash
tools/write-recovery-card.sh /dev/sdX
```

This overwrites only the first 80 MiB and performs SHA256 readback verification.

Be absolutely certain `/dev/sdX` is the intended microSD.
