# File Manifest

## `rtl/`
Current synthesizable HDL for the Intel 8080 system, RAM, serial interface, SD SPI engine, DCDD disk controller, setup controller and Nexys A7 top level.

## `constraints/`
Current Nexys A7 pin and timing constraints.

## `memory/`
Memory initialization files required by synthesis: RAM image, startup/setup text ROM and embedded A: boot tracks.

## `build/`
Portable Vivado Tcl build and QSPI programming scripts.

## `release/`
Latest captured timing-clean BIT/MCS plus route timing, DRC and utilization reports.

## `recovery/`
Exact first 80 MiB recovery image of the Stage 7.4 card state available when the master package was assembled.

## `tools/`
Portable shell wrappers for build, flash and card recovery.

## `docs/`
Architecture, operation, recovery, current status and GitHub publishing notes.
