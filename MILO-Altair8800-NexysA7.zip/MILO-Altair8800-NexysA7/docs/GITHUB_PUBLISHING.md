# Publishing to GitHub

Suggested repository name:

`MILO-Altair8800-NexysA7`

Suggested title:

**MILO Altair 8800 FPGA — Authentic 8080/CP/M Computer on the Nexys A7-100T**

Suggested description:

> A self-booting MITS Altair 8800-compatible FPGA appliance for the Digilent Nexys A7-100T: vm80a Intel 8080 core, authentic MITS DBL bootstrap, 56K CP/M 2.2 with 8 MB virtual storage, persistent microSD, autonomous QSPI boot, UART console, selectable 2–25 MHz runtime speeds, and live A0–A15 address LEDs.

## Important before making the repository public

The recovery image and memory/disk contents may include historical CP/M/Altair software. Confirm redistribution rights before publishing those binary assets publicly. If rights are uncertain, keep the full archive private and publish only material you have permission to redistribute.

## Basic Git commands

From inside the unpacked repository:

```bash
git init
git add .
git commit -m "Initial MILO Altair 8800 Stage 7.4 release"
git branch -M main
git remote add origin <your-repository-url>
git push -u origin main
```
