# Architecture

## Boot sequence

1. Nexys A7 configures itself from onboard QSPI x4.
2. Stage 7 setup logic initializes the microSD and loads persistent settings.
3. A five-second DEL setup window is offered.
4. The authentic MITS DBL bootstrap runs at 2 MHz.
5. CP/M boots through the 88-DCDD-style FPGA disk controller.
6. After CP/M begins serial activity, the CPU switches to the saved runtime speed.

## Major blocks

- `vm80a.v` — Intel 8080-compatible processor core
- `altair_ram64k.sv` — 64 KB memory
- `altair_2sio_uart.sv` — Altair 88-2SIO-compatible UART
- `sd_spi_block.sv` — SD SPI block engine
- `altair_dcdd_sd.sv` — DCDD disk interface / Stage 7.4 storage
- `altair_boot_setup.sv` — persistent setup menu and boot orchestration
- `altair_nexys_top_stage7.sv` — Nexys top level
- `altair_nexys_stage7.xdc` — pin/timing constraints

## Persistent settings

The FPGA configuration lives in QSPI. Setup preferences are stored in a reserved microSD configuration block (LBA 64). This cleanly separates hardware configuration from user/storage state.

## LEDs

- `LED[15:0] = ~addr[15:0]`
- RGB blue LED = disk activity
- red/green RGB channels disabled
- 7-segment display disabled
