# Operation

## Serial console

Use 115200 baud, 8 data bits, no parity, 1 stop bit.

## Startup

Normal boot requires no input. Press DEL during the five-second window to enter setup.

The line:

```text
Starting authentic MITS DBL -> CP/M at 2 MHz...
```

describes the bootstrap speed. It does not mean CP/M remains at 2 MHz. Once CP/M starts serial output, the selected saved runtime speed takes effect.

## Setup persistence

Use `X` (Save & Exit). Settings are saved to microSD and restored on later cold boots.

## CP/M storage

Known Stage 7.4 observations:

```text
A: 7940k free
B: 8168k free
```

Use B: as a large working/data drive.

## XMODEM receive

From B:

```text
B>A:PCGET filename.ext
```

Then start the XMODEM sender on the PC.

Do not invoke `PCGET` without a filename.
